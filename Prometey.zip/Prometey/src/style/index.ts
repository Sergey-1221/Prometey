import DefaultLayers from './DefaultLayers';

export default { DefaultLayers };
